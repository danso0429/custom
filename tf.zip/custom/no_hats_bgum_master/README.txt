Put the mods you are interested in in tf/custom/.
Get more info on the mods at https://gamebanana.com/mods/205768 or https://pevhs.ch/tf2/

