# LightHUD

My personal HUD aimed to be very minimal and light on performance, get's rid of many elements I don't personally feel the need of and with that brings a bit more stability with less freezes and some extra FPS.

Here are some of the screenshots, full album [HERE](https://imgur.com/a/kg9i6OU)

![](https://i.imgur.com/dc352zw.jpg)
![](https://i.imgur.com/SLkknry.jpg)
![](https://i.imgur.com/UcPU97G.jpg)
![](https://i.imgur.com/gw4hLg8.jpg)
![](https://i.imgur.com/FaeIKVX.jpg)
![](https://i.imgur.com/e1eEC4W.png)
![](https://i.imgur.com/LPYCrpj.jpg)
